#pragma once

#define __CLUTTER_DEPRECATED_H_INSIDE__

#include "clutter/deprecated/clutter-container.h"

#undef __CLUTTER_DEPRECATED_H_INSIDE__

